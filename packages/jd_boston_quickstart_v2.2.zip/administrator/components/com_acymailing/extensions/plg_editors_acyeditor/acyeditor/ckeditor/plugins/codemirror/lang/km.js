CKEDITOR.plugins.setLang( 'codemirror', 'km', {
	toolbar: 'កូត',
	searchCode: 'Search Source',
	autoFormat: 'Format Selection',
	commentSelectedRange: 'Comment Selection',
	uncommentSelectedRange: 'Uncomment Selection',
	autoCompleteToggle: 'Enable/Disable HTML Tag Autocomplete'
});

