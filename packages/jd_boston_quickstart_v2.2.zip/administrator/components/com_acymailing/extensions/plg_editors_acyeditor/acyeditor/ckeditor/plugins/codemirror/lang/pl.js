CKEDITOR.plugins.setLang( 'codemirror', 'pl', {
	toolbar: 'Źródło dokumentu',
	autoFormat: 'Sformatuj zaznaczenie',
	commentSelectedRange: 'Zakomentuj zaznaczenie',
	uncommentSelectedRange: 'Odkomentuj zaznaczenie',
	searchCode: 'Wyszukaj w źródle',
	autoCompleteToggle: 'Włącza/Wyłącza automatyczne uzupełniania tagów HTML'
});

