CKEDITOR.plugins.setLang( 'codemirror', 'nl', {
	toolbar: 'Broncode',
	searchCode: 'Zoek in broncode',
	autoFormat: 'Formatteer selectie',
	commentSelectedRange: 'Zet selectie in commentaar',
	uncommentSelectedRange: 'Haal selectie uit commentaar',
	autoCompleteToggle: 'Zet automatisch aanvullen van HTML tags aan/uit'
});

